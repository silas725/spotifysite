// 1. Your Spotify client ID
const clientId = "618cb87ab4eb47c282c7a1c8b27f56ef";

// 2. Your HTTPS callback URL
const redirectUri = "https://silas725.github.io/spotify-site/callback";

document.getElementById("login").onclick = () => {
  const scopes = [
    "streaming",
    "user-read-email",
    "user-read-private",
    "user-read-playback-state",
    "user-modify-playback-state"
  ];

  const url =
    "https://accounts.spotify.com/authorize" +
    "?response_type=token" +
    "&client_id=" + encodeURIComponent(clientId) +
    "&scope=" + encodeURIComponent(scopes.join(" ")) +
    "&redirect_uri=" + encodeURIComponent(redirectUri);

  window.location = url;
};
